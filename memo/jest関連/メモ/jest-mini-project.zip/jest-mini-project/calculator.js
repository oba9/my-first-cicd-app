// シンプルな電卓関数（Jestの練習用）
// add: 2つの数値の合計を返します
function add(a, b) {
  return a + b;
}

// sub: 2つの数値の差を返します
function sub(a, b) {
  return a - b;
}

// sum: 配列内の数値をすべて合計します
function sum(arr) {
  return arr.reduce((acc, cur) => acc + cur, 0);
}

module.exports = { add, sub, sum };
