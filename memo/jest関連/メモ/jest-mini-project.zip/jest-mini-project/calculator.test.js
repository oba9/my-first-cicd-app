const { add, sub, sum } = require('./calculator');

// 基本のテスト例
test('add(2, 3) は 5 になる', () => {
  expect(add(2, 3)).toBe(5);
});

test('sub(10, 4) は 6 になる', () => {
  expect(sub(10, 4)).toBe(6);
});

// toEqual の例（配列・オブジェクトは toBe ではなく toEqual を使う）
test('sum([1,2,3]) は 6 になる', () => {
  expect(sum([1,2,3])).toBe(6);
});

// 失敗パターンを not で表現
test('add(2, 2) は 5 ではない', () => {
  expect(add(2, 2)).not.toBe(5);
});
