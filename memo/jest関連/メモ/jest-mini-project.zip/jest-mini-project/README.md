# Jest 練習ミニプロジェクト（初心者向け）

これは **Jest（JavaScriptの自動テストツール）** を最短で体験するための最小プロジェクトです。
`add / sub / sum` の3つの関数をテストします。

---

## 📦 同梱ファイル
```txt
jest-mini-project/
├─ package.json          # npm スクリプトと依存（jest）を定義
├─ calculator.js         # 練習用の関数
├─ calculator.test.js    # 上の関数のテスト
└─ .gitignore            # node_modules などをGit管理から除外
```

---

## ▶ 実行手順（Windows / macOS / Linux 共通）

1. ZIP を展開して、フォルダへ移動します。  
   例）Windowsの場合：`jest-mini-project` フォルダを任意の場所に解凍

2. ターミナル（PowerShell / Git Bash / 端末）を開き、フォルダへ移動：
   ```bash
   cd <展開したフォルダのパス>/jest-mini-project
   ```

3. 依存をインストール：
   ```bash
   npm install
   ```
   > はじめて実行する時に **Jest** が入ります。（1分程度）

4. テストを実行：
   ```bash
   npm test
   ```
   すべて成功すると、以下のように表示されます。
   ```
   PASS  ./calculator.test.js
    ✓ add(2, 3) は 5 になる
    ✓ sub(10, 4) は 6 になる
    ✓ sum([1,2,3]) は 6 になる
    ✓ add(2, 2) は 5 ではない
   ```

5. （任意）テストを監視モードで実行：
   ```bash
   npm run test:watch
   ```
   ファイル保存のたびに自動で再実行され、学習に便利です。

6. （任意）カバレッジ（テスト網羅率）を確認：
   ```bash
   npm run coverage
   ```
   `coverage/` フォルダにレポートが出力されます。ブラウザで `coverage/lcov-report/index.html` を開くと可視化できます。

---

## 💡 よくあるトラブルと対処

- `npm: command not found`  
  → Node.js が未インストールです。公式サイトから LTS 版をインストールしてください。  
  https://nodejs.org/

- `npm test` で `jest` が見つからない  
  → `npm install` を忘れている可能性があります。もう一度実行してください。

- 日本語文字化け（WindowsのGit Bashなど）  
  → PowerShell か VS Code の「ターミナル」を使うと改善されることがあります。

---

## 🧠 仕組みの簡単な説明

- `calculator.test.js` に **期待する動作** を「仕様」として書きます。  
- `npm test` は **Jest** を起動し、`*.test.js` ファイルを自動で探して実行します。  
- 期待どおりなら ✅（PASS）、違っていれば ❌（FAIL）を表示します。

---

## 🧪 発展：自分でテストを追加してみよう

例）0や負の数、空配列のときなど、境界値のテストを追加：
```javascript
test('sum([]) は 0 になる', () => {
  expect(sum([])).toBe(0);
});
```

---

Happy Testing! 🎉
